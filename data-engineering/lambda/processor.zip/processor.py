import boto3
import gzip
import json
from datetime import datetime, timezone
from io import BytesIO
from urllib.parse import unquote_plus

s3 = boto3.client("s3")


def lambda_handler(event, context):
    """
    Lambda is triggered by S3 when new raw files land under raw/... in the bucket.

    For each raw GZIP file:
    - Downloads and decompresses it.
    - Reads line-delimited JSON events.
    - Removes the 'user_id' field (example of field removal).
    - Adds 'processed_ts' (example of enrichment).
    - Writes the transformed events as JSON lines to processed/year=.../month=.../day=.../
    """

    for record in event.get("Records", []):
        src_bucket = record["s3"]["bucket"]["name"]
        src_key = unquote_plus(record["s3"]["object"]["key"])

        # Download the raw GZIP file from S3
        raw_obj = s3.get_object(Bucket=src_bucket, Key=src_key)
        raw_body = raw_obj["Body"].read()

        # Decompress GZIP
        with gzip.GzipFile(fileobj=BytesIO(raw_body), mode="rb") as gz:
            file_content = gz.read().decode("utf-8")

        transformed_lines = []

        # Firehose writes newline-delimited JSON
        for line in file_content.splitlines():
            line = line.strip()
            if not line:
                continue

            try:
                event_obj = json.loads(line)
            except json.JSONDecodeError:
                # Skip malformed lines
                continue

            # --- Simple transformation logic ---

            # 1. Remove a field we don't want (example: user_id)
            event_obj.pop("user_id", None)

            # 2. Add an enrichment field (UTC timestamp when processed)
            event_obj["processed_ts"] = datetime.now(timezone.utc).isoformat()

            transformed_lines.append(json.dumps(event_obj))

        if not transformed_lines:
            # Nothing useful to write for this file
            continue

        transformed_body = "\n".join(transformed_lines).encode("utf-8")

        # Map raw/... → processed/...
        # Example:
        #   raw/year=2025/month=11/day=26/...
        # → processed/year=2025/month=11/day=26/...
        if src_key.startswith("raw/"):
            rest = src_key[len("raw/"):]  # year=YYYY/...
            dest_key = f"processed/{rest}"
        else:
            dest_key = f"processed/{src_key}"

        # Replace .gz suffix with .json
        if dest_key.endswith(".gz"):
            dest_key = dest_key[:-3] + "json"

        # Upload transformed file back to S3
        s3.put_object(
            Bucket=src_bucket,
            Key=dest_key,
            Body=transformed_body,
            ContentType="application/json",
        )

    return {"status": "ok"}
